package com.uniminuto.clinica.apicontroller;

import com.uniminuto.clinica.api.RecetaApi;
import com.uniminuto.clinica.entity.Receta;
import com.uniminuto.clinica.service.RecetaService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controlador REST para la gestión de recetas médicas.
 * Implementa los endpoints definidos en la interfaz RecetaApi.
 *
 * @author anago
 */
@RestController
@RequestMapping("/api/recetas")
public class RecetaApiController implements RecetaApi {

    @Autowired
    private RecetaService recetaService;

    /**
     * {@inheritDoc}
     */
    @Override
    public ResponseEntity<Receta> crearReceta(Receta receta) {
        try {
            Receta nuevaReceta = recetaService.crearReceta(receta);
            return ResponseEntity.status(HttpStatus.CREATED).body(nuevaReceta);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(null);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ResponseEntity<List<Receta>> listarRecetasOrdenadas() {
        try {
            List<Receta> recetas = recetaService.getAllRecetasOrdenadas();
            return ResponseEntity.ok(recetas);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ResponseEntity<List<Receta>> buscarRecetasPorCita(Long citaId) {
        try {
            List<Receta> recetas = recetaService.getRecetasPorCita(citaId);
            return ResponseEntity.ok(recetas);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ResponseEntity<Receta> buscarRecetaPorId(Long id) {
        try {
            Receta receta = recetaService.getRecetaPorId(id);
            if (receta != null) {
                return ResponseEntity.ok(receta);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ResponseEntity<Receta> actualizarReceta(Long id, Receta receta) {
        try {
            Receta recetaActualizada = recetaService.actualizarReceta(id, receta);
            if (recetaActualizada != null) {
                return ResponseEntity.ok(recetaActualizada);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(null);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ResponseEntity<Void> eliminarReceta(Long id) {
        try {
            recetaService.eliminarReceta(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}