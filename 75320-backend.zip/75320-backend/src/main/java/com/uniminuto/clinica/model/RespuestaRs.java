package com.uniminuto.clinica.model;

import lombok.Data;

/**
 *
 * @author lmora
 */
@Data
public class RespuestaRs {
    private String message;
    private boolean estaFuncionando;

    public void setMessage(String message) {
        this.message = message;
    }

    public void setEstaFuncionando(boolean estaFuncionando) {
        this.estaFuncionando = estaFuncionando;
    }
}
