package com.uniminuto.clinica.service;

import com.uniminuto.clinica.entity.Receta;
import java.util.List;

/**
 * Servicio para gestionar operaciones relacionadas con recetas médicas.
 *
 * @author anago
 */
public interface RecetaService {

    /**
     * Obtiene todas las recetas ordenadas por fecha de creación descendente.
     *
     * @return Lista de recetas ordenadas de más recientes a más antiguas
     */
    List<Receta> getAllRecetasOrdenadas();

    /**
     * Obtiene recetas por ID de cita.
     *
     * @param citaId ID de la cita
     * @return Lista de recetas de la cita
     */
    List<Receta> getRecetasPorCita(Long citaId);

    /**
     * Crea una nueva receta médica.
     *
     * @param receta Objeto Receta a crear
     * @return Receta creada y guardada
     * @throws RuntimeException si la receta no tiene cita asociada o campos obligatorios faltantes
     */
    Receta crearReceta(Receta receta);

    /**
     * Busca una receta por su ID.
     *
     * @param id ID de la receta
     * @return Receta encontrada
     * @throws RuntimeException si la receta no existe
     */
    Receta getRecetaPorId(Long id);

    /**
     * Elimina una receta por su ID.
     *
     * @param id ID de la receta a eliminar
     * @throws RuntimeException si la receta no existe
     */
    void eliminarReceta(Long id);

    /**
     * Actualiza una receta existente.
     *
     * @param id ID de la receta a actualizar
     * @param receta Receta con los datos actualizados
     * @return Receta actualizada
     * @throws RuntimeException si la receta no existe
     */
    Receta actualizarReceta(Long id, Receta receta);
}