package com.uniminuto.clinica.service;

import com.uniminuto.clinica.entity.Cita;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Servicio para gestionar operaciones relacionadas con citas médicas.
 *
 * @author anago
 */
public interface CitaService {

    /**
     * Crea una nueva cita médica.
     *
     * @param cita Objeto Cita a crear
     * @return Cita creada y guardada
     */
    Cita crearCita(Cita cita);

    /**
     * Obtiene todas las citas ordenadas por fecha y hora descendente.
     *
     * @return Lista de citas ordenadas de más recientes a más antiguas
     */
    List<Cita> getAllCitasOrdenadas();

    /**
     * Obtiene citas por ID de paciente.
     *
     * @param pacienteId ID del paciente
     * @return Lista de citas del paciente
     */
    List<Cita> getCitasPorPaciente(Long pacienteId);

    /**
     * Obtiene citas por ID de médico.
     *
     * @param medicoId ID del médico
     * @return Lista de citas del médico
     */
    List<Cita> getCitasPorMedico(Long medicoId);

    /**
     * Obtiene citas por estado.
     *
     * @param estado Estado de la cita
     * @return Lista de citas con el estado especificado
     */
    List<Cita> getCitasPorEstado(String estado);

    /**
     * Obtiene una cita por su ID.
     *
     * @param id ID de la cita
     * @return Optional con la cita encontrada
     */
    Optional<Cita> getCitaPorId(Long id);

    /**
     * Actualiza una cita existente.
     *
     * @param cita Cita con los datos actualizados
     * @return Cita actualizada
     */
    Cita actualizarCita(Cita cita);

    /**
     * Cancela una cita por su ID.
     *
     * @param id ID de la cita a cancelar
     * @return Cita cancelada
     */
    Cita cancelarCita(Long id);

    /**
     * Confirma una cita por su ID.
     *
     * @param id ID de la cita a confirmar
     * @return Cita confirmada
     */
    Cita confirmarCita(Long id);

    /**
     * Elimina una cita por su ID.
     *
     * @param id ID de la cita a eliminar
     */
    void eliminarCita(Long id);

    /**
     * Verifica disponibilidad de médico en una fecha y hora específica.
     *
     * @param medicoId ID del médico
     * @param fechaHora Fecha y hora a verificar
     * @return true si está disponible, false si ya tiene cita
     */
    boolean verificarDisponibilidadMedico(Long medicoId, LocalDateTime fechaHora);
}