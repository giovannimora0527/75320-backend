package com.uniminuto.clinica.service.Impl;

import com.uniminuto.clinica.entity.Receta;
import com.uniminuto.clinica.repository.RecetaRepository;
import com.uniminuto.clinica.service.RecetaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Implementación del servicio para operaciones relacionadas con recetas médicas.
 *
 * @author anago
 */
@Service
@Transactional
public class RecetaServiceImpl implements RecetaService {

    @Autowired
    private RecetaRepository recetaRepository;

    @Override
    @Transactional(readOnly = true)
    public List<Receta> getAllRecetasOrdenadas() {
        return recetaRepository.findAllByOrderByFechaCreacionRegistroDesc();
    }

    @Override
    @Transactional(readOnly = true)
    public List<Receta> getRecetasPorCita(Long citaId) {
        return recetaRepository.findByCitaId(citaId);
    }

    @Override
    public Receta crearReceta(Receta receta) {
        try {
            // Validar que la receta tenga una cita asociada
            if (receta.getCita() == null || receta.getCita().getId() == null) {
                throw new RuntimeException("La receta debe estar asociada a una cita");
            }

            // Validar que los campos obligatorios estén presentes
            if (receta.getMedicamento() == null || receta.getMedicamento().trim().isEmpty()) {
                throw new RuntimeException("El medicamento es obligatorio");
            }

            if (receta.getDosis() == null || receta.getDosis().trim().isEmpty()) {
                throw new RuntimeException("La dosis es obligatoria");
            }

            // Establecer fecha de creación
            receta.setFechaCreacionRegistro(LocalDateTime.now());
            
            return recetaRepository.save(receta);
        } catch (RuntimeException e) {
            throw new RuntimeException("Error al crear la receta: " + e.getMessage(), e);
        }
    }

    @Override
    @Transactional(readOnly = true)
    public Receta getRecetaPorId(Long id) {
        return recetaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Receta no encontrada con ID: " + id));
    }

    @Override
    public void eliminarReceta(Long id) {
        try {
            // Verificar que la receta existe antes de eliminar
            if (!recetaRepository.existsById(id)) {
                throw new RuntimeException("No se encontró la receta con ID: " + id);
            }
            recetaRepository.deleteById(id);
        } catch (RuntimeException e) {
            throw new RuntimeException("Error al eliminar la receta: " + e.getMessage(), e);
        }
    }

    @Override
    public Receta actualizarReceta(Long id, Receta receta) {
        try {
            return recetaRepository.findById(id)
                .map(recetaExistente -> {
                    // Actualizar solo los campos permitidos
                    if (receta.getMedicamento() != null) {
                        recetaExistente.setMedicamento(receta.getMedicamento());
                    }
                    if (receta.getDosis() != null) {
                        recetaExistente.setDosis(receta.getDosis());
                    }
                    if (receta.getIndicaciones() != null) {
                        recetaExistente.setIndicaciones(receta.getIndicaciones());
                    }
                    
                    // No se permite actualizar la cita ni la fecha de creación
                    return recetaRepository.save(recetaExistente);
                })
                .orElseThrow(() -> new RuntimeException("Receta no encontrada con ID: " + id));
        } catch (Exception e) {
            throw new RuntimeException("Error al actualizar la receta: " + e.getMessage(), e);
        }
    }
}