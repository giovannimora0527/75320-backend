package com.uniminuto.clinica.service.Impl;

import com.uniminuto.clinica.entity.Cita;
import com.uniminuto.clinica.entity.Medico;
import com.uniminuto.clinica.repository.CitaRepository;
import com.uniminuto.clinica.service.CitaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Implementación del servicio para operaciones relacionadas con citas médicas.
 *
 * @author anago
 */
@Service
@Transactional
public class CitaServiceImpl implements CitaService {

    @Autowired
    private CitaRepository citaRepository;

    @Override
    public Cita crearCita(Cita cita) {
        try {
            // Validar que la cita tenga médico y paciente
            if (cita.getMedico() == null || cita.getMedico().getId() == null) {
                throw new RuntimeException("Debe seleccionar un médico para la cita");
            }
            
            if (cita.getPaciente() == null || cita.getPaciente().getId() == null) {
                throw new RuntimeException("Debe seleccionar un paciente para la cita");
            }

            // Validar disponibilidad del médico
            Long medicoId = cita.getMedico().getId();
            if (!verificarDisponibilidadMedico(medicoId, cita.getFechaHora())) {
                throw new RuntimeException("El médico no está disponible en la fecha y hora seleccionada");
            }

            // Establecer estado inicial si no está definido
            if (cita.getEstado() == null || cita.getEstado().isEmpty()) {
                cita.setEstado("programada");
            }

            return citaRepository.save(cita);
        } catch (RuntimeException e) {
            throw new RuntimeException("Error al crear la cita: " + e.getMessage(), e);
        }
    }

    @Override
    @Transactional(readOnly = true)
    public List<Cita> getAllCitasOrdenadas() {
        return citaRepository.findAllByOrderByFechaHoraDesc();
    }

    @Override
    @Transactional(readOnly = true)
    public List<Cita> getCitasPorPaciente(Long pacienteId) {
        return citaRepository.findByPacienteId(pacienteId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Cita> getCitasPorMedico(Long medicoId) {
        return citaRepository.findByMedicoId(medicoId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Cita> getCitasPorEstado(String estado) {
        return citaRepository.findByEstado(estado);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Cita> getCitaPorId(Long id) {
        return citaRepository.findById(id);
    }

    @Override
    public Cita actualizarCita(Cita cita) {
        try {
            // Verificar que la cita existe
            if (!citaRepository.existsById(cita.getId())) {
                throw new RuntimeException("No se encontró la cita con ID: " + cita.getId());
            }

            // Validar disponibilidad del médico (excluyendo la cita actual)
            Long medicoId = cita.getMedico().getId();
            if (!verificarDisponibilidadMedicoParaActualizacion(medicoId, cita.getFechaHora(), cita.getId())) {
                throw new RuntimeException("El médico no está disponible en la fecha y hora seleccionada");
            }

            return citaRepository.save(cita);
        } catch (Exception e) {
            throw new RuntimeException("Error al actualizar la cita: " + e.getMessage(), e);
        }
    }

    @Override
    public Cita cancelarCita(Long id) {
        try {
            Cita cita = citaRepository.findById(id)
                    .orElseThrow(() -> new RuntimeException("No se encontró la cita con ID: " + id));
            
            cita.setEstado("cancelada");
            return citaRepository.save(cita);
        } catch (Exception e) {
            throw new RuntimeException("Error al cancelar la cita: " + e.getMessage(), e);
        }
    }

    @Override
    public Cita confirmarCita(Long id) {
        try {
            Cita cita = citaRepository.findById(id)
                    .orElseThrow(() -> new RuntimeException("No se encontró la cita con ID: " + id));
            
            cita.setEstado("confirmada");
            return citaRepository.save(cita);
        } catch (Exception e) {
            throw new RuntimeException("Error al confirmar la cita: " + e.getMessage(), e);
        }
    }

    @Override
    public void eliminarCita(Long id) {
        try {
            if (!citaRepository.existsById(id)) {
                throw new RuntimeException("No se encontró la cita con ID: " + id);
            }
            citaRepository.deleteById(id);
        } catch (Exception e) {
            throw new RuntimeException("Error al eliminar la cita: " + e.getMessage(), e);
        }
    }

    @Override
    @Transactional(readOnly = true)
    public boolean verificarDisponibilidadMedico(Long medicoId, LocalDateTime fechaHora) {
        // Considerar un margen de 30 minutos para evitar solapamientos
        LocalDateTime inicio = fechaHora.minusMinutes(30);
        LocalDateTime fin = fechaHora.plusMinutes(30);
        
        List<Cita> citasExistentes = citaRepository.findByMedicoIdAndFechaHoraBetween(medicoId, inicio, fin);
        return citasExistentes.isEmpty();
    }

    /**
     * Verifica disponibilidad del médico excluyendo una cita específica (para actualizaciones)
     */
    private boolean verificarDisponibilidadMedicoParaActualizacion(Long medicoId, LocalDateTime fechaHora, Long citaId) {
        LocalDateTime inicio = fechaHora.minusMinutes(30);
        LocalDateTime fin = fechaHora.plusMinutes(30);
        
        List<Cita> citasExistentes = citaRepository.findByMedicoIdAndFechaHoraBetweenExcluyendoCita(medicoId, inicio, fin, citaId);
        return citasExistentes.isEmpty();
    }
}