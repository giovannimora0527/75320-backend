package com.uniminuto.clinica.repository;

import com.uniminuto.clinica.entity.Receta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Repositorio para gestionar operaciones de base de datos para la entidad Receta.
 *
 * @author anago
 */
@Repository
public interface RecetaRepository extends JpaRepository<Receta, Long> {
    
    /**
     * Encuentra recetas por ID de cita.
     *
     * @param citaId ID de la cita
     * @return Lista de recetas de la cita
     */
    List<Receta> findByCitaId(Long citaId);
    
    /**
     * Encuentra todas las recetas ordenadas por fecha de creación descendente.
     *
     * @return Lista de recetas ordenadas
     */
    List<Receta> findAllByOrderByFechaCreacionRegistroDesc();
    
    /**
     * Encuentra recetas por nombre de medicamento (búsqueda case-insensitive).
     *
     * @param medicamento Nombre o parte del nombre del medicamento
     * @return Lista de recetas que contienen el medicamento
     */
    List<Receta> findByMedicamentoContainingIgnoreCase(String medicamento);
    
    /**
     * Cuenta las recetas por ID de cita.
     *
     * @param citaId ID de la cita
     * @return Número de recetas para la cita
     */
    Long countByCitaId(Long citaId);
    
    /**
     * Encuentra recetas creadas después de una fecha específica.
     *
     * @param fecha Fecha límite
     * @return Lista de recetas recientes
     */
    List<Receta> findByFechaCreacionRegistroAfter(LocalDateTime fecha);
    
    /**
     * Query personalizada para encontrar recetas recientes (últimas 24 horas).
     *
     * @return Lista de recetas recientes
     */
    @Query("SELECT r FROM Receta r WHERE r.fechaCreacionRegistro >= :fecha ORDER BY r.fechaCreacionRegistro DESC")
    List<Receta> findRecetasRecientes(@Param("fecha") LocalDateTime fecha);
    
    /**
     * Verifica si existe una receta para una cita específica.
     *
     * @param citaId ID de la cita
     * @return true si existe al menos una receta para la cita
     */
    boolean existsByCitaId(Long citaId);
}