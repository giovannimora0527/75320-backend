package com.uniminuto.clinica.repository;

import com.uniminuto.clinica.entity.Cita;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Repositorio para gestionar operaciones de base de datos para la entidad Cita.
 *
 * @author anago
 */
@Repository
public interface CitaRepository extends JpaRepository<Cita, Long> {

    /**
     * Encuentra citas por ID de paciente.
     *
     * @param pacienteId ID del paciente
     * @return Lista de citas del paciente
     */
    List<Cita> findByPacienteId(Long pacienteId);

    /**
     * Encuentra citas por ID de médico.
     *
     * @param medicoId ID del médico
     * @return Lista de citas del médico
     */
    List<Cita> findByMedicoId(Long medicoId);

    /**
     * Encuentra citas por estado.
     *
     * @param estado Estado de la cita
     * @return Lista de citas con el estado especificado
     */
    List<Cita> findByEstado(String estado);

    /**
     * Encuentra citas entre un rango de fechas.
     *
     * @param startFecha Fecha inicial
     * @param endFecha Fecha final
     * @return Lista de citas en el rango de fechas
     */
    @Query("SELECT c FROM Cita c WHERE c.fechaHora BETWEEN :startFecha AND :endFecha ORDER BY c.fechaHora DESC")
    List<Cita> findCitasBetweenDates(@Param("startFecha") LocalDateTime startFecha, 
                                   @Param("endFecha") LocalDateTime endFecha);

    /**
     * Encuentra todas las citas ordenadas por fecha y hora descendente.
     *
     * @return Lista de citas ordenadas
     */
    List<Cita> findAllByOrderByFechaHoraDesc();

    /**
     * Encuentra citas de un médico en un rango de fechas.
     *
     * @param medicoId ID del médico
     * @param startFecha Fecha inicial
     * @param endFecha Fecha final
     * @return Lista de citas del médico en el rango
     */
    @Query("SELECT c FROM Cita c WHERE c.medico.id = :medicoId AND c.fechaHora BETWEEN :startFecha AND :endFecha")
    List<Cita> findByMedicoIdAndFechaHoraBetween(@Param("medicoId") Long medicoId,
                                               @Param("startFecha") LocalDateTime startFecha,
                                               @Param("endFecha") LocalDateTime endFecha);

    /**
     * Encuentra citas de un médico en un rango de fechas, excluyendo una cita específica.
     *
     * @param medicoId ID del médico
     * @param startFecha Fecha inicial
     * @param endFecha Fecha final
     * @param citaId ID de la cita a excluir
     * @return Lista de citas del médico en el rango, excluyendo la cita especificada
     */
    @Query("SELECT c FROM Cita c WHERE c.medico.id = :medicoId AND c.fechaHora BETWEEN :startFecha AND :endFecha AND c.id != :citaId")
    List<Cita> findByMedicoIdAndFechaHoraBetweenExcluyendoCita(@Param("medicoId") Long medicoId,
                                                             @Param("startFecha") LocalDateTime startFecha,
                                                             @Param("endFecha") LocalDateTime endFecha,
                                                             @Param("citaId") Long citaId);
}