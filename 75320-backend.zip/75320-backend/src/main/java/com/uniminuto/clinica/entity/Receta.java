package com.uniminuto.clinica.entity;

import java.io.Serializable;
import java.time.LocalDateTime;
import javax.persistence.*;
import lombok.Data;

/**
 * Entidad que representa una receta médica en el sistema de clínica.
 * Una receta está asociada a una cita médica.
 *
 * @author anago
 */
@Data
@Entity
@Table(name = "receta", schema = "clinica")
public class Receta implements Serializable {

    private static final long serialVersionUID = 1L;

    /** Identificador único de la receta. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    /** Cita médica asociada a esta receta. */
    @ManyToOne
    @JoinColumn(name = "cita_id", nullable = false)
    private Cita cita;

    /** Nombre del medicamento prescrito. */
    @Column(name = "medicamento", nullable = false, length = 200)
    private String medicamento;

    /** Dosis del medicamento. */
    @Column(name = "dosis", nullable = false, length = 100)
    private String dosis;

    /** Indicaciones para el uso del medicamento. */
    @Column(name = "indicaciones", length = 500)
    private String indicaciones;

    /** Fecha y hora de creación del registro de la receta. */
    @Column(name = "fecha_creacion_registro", nullable = false)
    private LocalDateTime fechaCreacionRegistro;

    /** Constructor por defecto. */
    public Receta() {}

    /** Constructor con parámetros básicos. */
    public Receta(Cita cita, String medicamento, String dosis, String indicaciones) {
        this.cita = cita;
        this.medicamento = medicamento;
        this.dosis = dosis;
        this.indicaciones = indicaciones;
        this.fechaCreacionRegistro = LocalDateTime.now();
    }

    /** Establece la fecha de creación automáticamente antes de persistir. */
    @PrePersist
    protected void onCreate() {
        if (fechaCreacionRegistro == null) {
            fechaCreacionRegistro = LocalDateTime.now();
        }
    }

    public void setFechaCreacionRegistro(LocalDateTime fechaCreacionRegistro) {
        this.fechaCreacionRegistro = fechaCreacionRegistro;
    }

    public Cita getCita() {
        return cita;
    }

    public String getMedicamento() {
        return medicamento;
    }

    public String getDosis() {
        return dosis;
    }

    public void setMedicamento(String medicamento) {
        this.medicamento = medicamento;
    }

    public void setDosis(String dosis) {
        this.dosis = dosis;
    }

    public String getIndicaciones() {
        return indicaciones;
    }

    public void setIndicaciones(String indicaciones) {
        this.indicaciones = indicaciones;
    }

    public void setCita(Cita cita) {
        this.cita = cita;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDateTime getFechaCreacionRegistro() {
        return fechaCreacionRegistro;
    }
}